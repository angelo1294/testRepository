#!/bin/bash
param (
    [string]$param = "Some parameter",
 )

echo "Displaying$param"